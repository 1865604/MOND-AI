const express = require('express');
const cors = require('cors');
const fetch = require('node-fetch');
appDiv.innerHTML = `<h1>MOND AI</h1>`;
const app = express();
app.use(cors());
app.use(express.json());

// 🔑 Groq APIキーをここに入れる
const API_KEY =
  'xai-IGpJkRC7nd5DTttYHFESskwpTQSEZ6bmIdejTLxOhj4mxaJP3TbTBkZUaMWeu4RFaCq1meEu2zLrrVqF';

app.post('/chat', async (req, res) => {
  const message = req.body.message;

  try {
    const response = await fetch(
      'https://api.groq.com/openai/v1/chat/completions',
      {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${API_KEY}`,
        },
        body: JSON.stringify({
          model: 'llama-3.1-8b-instant',
          messages: [
            {
              role: 'system',
              content:
                'あなたは『もん君』という元気でやさしい日本語キャラクターAIです。短く、やさしく、少し子どもっぽく話します。語尾に時々「ちゅん」をつけてもいいです。',
            },
            {
              role: 'user',
              content: message,
            },
          ],
        }),
      }
    );

    const data = await response.json();

    const reply =
      data.choices?.[0]?.message?.content ||
      data.error?.message ||
      'ごめん、うまく返せなかったよ';

    res.json({ reply });
  } catch (err) {
    res.json({ reply: 'サーバーエラー：' + err.message });
  }
});

app.listen(3000, () => {
  console.log('もん君起動中');
});
